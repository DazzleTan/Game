Run the game by executing the blocks.py file.
